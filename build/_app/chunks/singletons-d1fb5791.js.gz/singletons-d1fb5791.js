let t;function c(c){t=c.client}export{t as c,c as i};
